<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrar producto</title>
</head>
<body>
    <h1>Registrar producto</h1>
    <form action="${pageContext.request.contextPath}/productos" method="post">
        <label>Nombre:</label>
        <input type="text" name="nombre" required><br>
        <label>Precio:</label>
        <input type="number" step="0.01" name="precio" required><br>
        <label>Cantidad:</label>
        <input type="number" name="cantidad" required><br>
        <button type="submit">Guardar</button>
    </form>
    <p><a href="${pageContext.request.contextPath}/productos">Ver productos</a></p>
</body>
</html>
