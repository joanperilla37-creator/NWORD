<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="modelo.Producto" %>
<%
    List<Producto> productos = (List<Producto>) request.getAttribute("productos");
    if (productos == null) {
        productos = java.util.Collections.emptyList();
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Productos</title>
</head>
<body>
    <h1>Productos registrados</h1>
    <table border="1" cellpadding="6">
        <tr>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Cantidad</th>
        </tr>
        <% for (Producto producto : productos) { %>
        <tr>
            <td><%= producto.getNombre() %></td>
            <td><%= producto.getPrecio() %></td>
            <td><%= producto.getCantidad() %></td>
        </tr>
        <% } %>
    </table>
    <p><a href="${pageContext.request.contextPath}/">Agregar otro producto</a></p>
</body>
</html>
