package dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import modelo.Producto;

public class ProductoDAO {
    private static final List<Producto> PRODUCTOS = new ArrayList<>();

    public void guardar(Producto producto) {
        PRODUCTOS.add(producto);
    }

    public List<Producto> listar() {
        return Collections.unmodifiableList(PRODUCTOS);
    }
}
