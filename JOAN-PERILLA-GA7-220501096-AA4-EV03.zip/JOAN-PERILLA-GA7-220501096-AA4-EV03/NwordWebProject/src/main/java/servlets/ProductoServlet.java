package servlets;

import java.io.IOException;

import dao.ProductoDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import modelo.Producto;

public class ProductoServlet extends HttpServlet {
    private final ProductoDAO productoDAO = new ProductoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("productos", productoDAO.listar());
        request.getRequestDispatcher("/productos.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String precioParam = request.getParameter("precio");
        String cantidadParam = request.getParameter("cantidad");

        if (nombre == null || nombre.isBlank() || precioParam == null || cantidadParam == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Datos incompletos");
            return;
        }

        Producto producto = new Producto(nombre, Double.parseDouble(precioParam), Integer.parseInt(cantidadParam));
        productoDAO.guardar(producto);

        request.setAttribute("productos", productoDAO.listar());
        request.getRequestDispatcher("/productos.jsp").forward(request, response);
    }
}
