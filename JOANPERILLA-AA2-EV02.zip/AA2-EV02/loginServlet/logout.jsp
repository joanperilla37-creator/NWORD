<%
    session.invalidate(); // Cierra la sesi�n
    response.sendRedirect("index.jsp"); // Vuelve al login
%>
