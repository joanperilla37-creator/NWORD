<%-- 
    Document   : bienvenida
    Created on : 13/05/2026, 12:36:50?a.�m.
    Author     : zarck
--%>

<%@ page import="jakarta.servlet.http.HttpSession" %>
<%
    HttpSession sesion = request.getSession(false);
    String usuario = (sesion != null) ? (String) sesion.getAttribute("usuario") : null;
    if (usuario == null) {
        response.sendRedirect("index.jsp"); // Si no hay sesi�n, vuelve al login
    }
%>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>P�gina de Bienvenida</title>
        <link
            rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css"
            >
    </head>
    <body>
        <h2>Bienvenido, <%= usuario%> ?</h2>
        <p>Has iniciado sesi�n correctamente.</p>
        <a href="logout.jsp">Cerrar sesi�n</a>
    </body>
</html>
