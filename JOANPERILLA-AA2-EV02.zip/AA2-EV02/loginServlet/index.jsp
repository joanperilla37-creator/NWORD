<%-- 
    Document   : index
    Created on : 13/05/2026, 12:44:37?a.�m.
    Author     : zarck
--%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>
<body>
    <h2>Iniciar sesi�n</h2>

    <!-- Mostrar mensaje de error si viene en la URL -->
    <%
        String error = request.getParameter("error");
        if (error != null) {
            if ("1".equals(error)) {
                out.println("<p style='color:red;'>Usuario o contrase�a incorrectos ?</p>");
            } else if ("db".equals(error)) {
                out.println("<p style='color:red;'>Error de conexi�n con la base de datos ??</p>");
            }
        }
    %>

    <!-- Formulario que env�a al Servlet /login -->
    <form action="login" method="post">
        <label for="usuario">Usuario:</label>
        <input type="text" id="usuario" name="usuario" required><br><br>

        <label for="contrase�a">Contrase�a:</label>
        <input type="password" id="contrase�a" name="contrase�a" required><br><br>

        <input type="submit" value="Ingresar">
    </form>
</body>
</html>
